---
name: Documentation and Example Improvements
about: Use this to suggest changes to documentation and examples
title: ''
labels: enhancement
assignees: ''

---

- Include a link to the documentation section or the example

- Describe the confusion

- Suggest changes that would help
