export class Game {
  id:number;
  gameName:string;
  Assignee:string;
  Priority:string;
  Deadline:string;
  State:string;
}
