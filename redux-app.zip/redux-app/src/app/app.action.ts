export class AppAction {
  type: string;
  payload?: any;
}
