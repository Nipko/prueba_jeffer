import { Component } from '@angular/core';
import { fromEvent, combineLatest } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title = 'NgRx Games CRUD Demo';
}
