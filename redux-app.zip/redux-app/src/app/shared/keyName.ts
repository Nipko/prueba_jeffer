export class KeyName {
  id: number;
  name: string;
  checked = false;
}
